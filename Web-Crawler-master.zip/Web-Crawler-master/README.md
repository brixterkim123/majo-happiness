![](https://www.facebook.com/photo.php?fbid=1777767415575226&set=a.148589425159708.23305.100000259535011&type=3&theater)


# Spider based on thenewboston's web crawler

This is sample crawler used as my personal project based on thenewboston's crawler

***
Note: This does not use any other third party parser
